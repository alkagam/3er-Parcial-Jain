// --- APLICACIÓN REACT PARA 'TIENDA LA MODERNA' - SIN TAILWIND CSS ---
// Este es el componente principal (App.js) de tu aplicación React.
// Se ubicará en la carpeta 'Proyecto/tienda-frontend/src/App.js'

import React, { useState, useEffect } from 'react';
import './index.css'; // Importa el CSS global sin directivas de Tailwind

// URL base de tu API de Node.js
const API_BASE_URL = 'http://localhost:5000';

// Componente simple de Modal de Alerta (sin estilos de Tailwind)
const AlertDialog = ({ message, onClose }) => {
  if (!message) return null;
  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 50
    }}>
      <div style={{
        backgroundColor: 'white', padding: '20px', borderRadius: '8px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', maxWidth: '400px', width: '100%', margin: '0 16px'
      }}>
        <h3 style={{ fontSize: '20px', fontWeight: '600', color: '#333', marginBottom: '16px' }}>Mensaje del Sistema</h3>
        <p style={{ color: '#555', marginBottom: '24px' }}>{message}</p>
        <button
          onClick={onClose}
          style={{
            width: '100%', backgroundColor: '#2563eb', color: 'white',
            fontWeight: 'bold', padding: '10px 16px', borderRadius: '6px',
            border: 'none', cursor: 'pointer', transition: 'background-color 0.3s'
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#1d4ed8'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#2563eb'}
        >
          Aceptar
        </button>
      </div>
    </div>
  );
};

function App() {
  const [productos, setProductos] = useState([]);
  const [productosBajoStock, setProductosBajoStock] = useState([]);
  const [productosPorCaducar, setProductosPorCaducar] = useState([]);
  const [corteCaja, setCorteCaja] = useState(null);
  const [fechaCorte, setFechaCorte] = useState('');

  // Estados para el formulario de nueva venta
  const [newSale, setNewSale] = useState({
    cliente_id: '',
    usuario_id: '3', // Por defecto, usuario 'vendedor1'
    metodo_pago: 'EFECTIVO',
    detalles: [] // Array de { producto_id, cantidad, precio_unitario, nombre_producto }
  });
  const [currentProductToAddId, setCurrentProductToAddId] = useState('');
  const [currentProductToAddQuantity, setCurrentProductToAddQuantity] = useState(1);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [alertMessage, setAlertMessage] = useState(null); // Estado para la modal de alerta

  // Función para mostrar alerta
  const showAlert = (message) => setAlertMessage(message);
  const closeAlert = () => setAlertMessage(null);

  const getTodayDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Efecto para cargar todos los datos iniciales
  useEffect(() => {
    async function fetchData() {
      try {
        const [
          responseProductos,
          responseBajoStock,
          responsePorCaducar
        ] = await Promise.all([
          fetch(`${API_BASE_URL}/api/productos`),
          fetch(`${API_BASE_URL}/api/productos/bajo-stock`),
          fetch(`${API_BASE_URL}/api/productos/por-caducar`)
        ]);

        // Manejo de errores de respuesta HTTP
        if (!responseProductos.ok) throw new Error(`Error HTTP al obtener productos: ${responseProductos.status}`);
        if (!responseBajoStock.ok) throw new Error(`Error HTTP al obtener bajo stock: ${responseBajoStock.status}`);
        if (!responsePorCaducar.ok) throw new Error(`Error HTTP al obtener por caducar: ${responsePorCaducar.status}`);

        const dataProductos = await responseProductos.json();
        const dataBajoStock = await responseBajoStock.json();
        const dataPorCaducar = await responsePorCaducar.json();

        // Mapear los arrays de resultados de la API a objetos con nombres de propiedades
        // para facilitar el acceso en React.
        setProductos(dataProductos.map(p => ({
            id: p[0], nombre: p[1], descripcion: p[2], precio_venta: p[3],
            precio_compra: p[4], stock_actual: p[5], fecha_caducidad: p[6],
            categoria_id: p[7], proveedor_id: p[8], activo: p[9]
        })));
        setProductosBajoStock(dataBajoStock.map(p => ({
            id: p[0], nombre: p[1], descripcion: p[2], stock_actual: p[3],
            precio_venta: p[4], categoria_nombre: p[5], proveedor_nombre: p[6]
        })));
        setProductosPorCaducar(dataPorCaducar.map(p => ({
            id: p[0], nombre: p[1], descripcion: p[2], stock_actual: p[3],
            fecha_caducidad: p[4], precio_venta: p[5], categoria_nombre: p[6]
        })));

        setFechaCorte(getTodayDate());

      } catch (err) {
        console.error("Error al cargar datos:", err);
        setError(err);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, []); // El array vacío asegura que se ejecute solo una vez al montar el componente

  const handleCorteCaja = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE_URL}/api/corte-caja?fecha=${fechaCorte}`);
      if (!response.ok) {
        if (response.status === 404) {
          const errorData = await response.json();
          setCorteCaja(null);
          showAlert(errorData.message);
          return;
        }
        throw new Error(`Error HTTP al obtener corte de caja: ${response.status}`);
      }
      const data = await response.json();
      // oracledb devuelve los resultados como un array de arrays, por ejemplo:
      // [ [ FECHA_CORTE_OBJ, TOTAL_EFECTIVO, TOTAL_TARJETA, TOTAL_TRANSFERENCIA, TOTAL_GENERAL ] ]
      // Mapeamos a un objeto con nombres de propiedades para facilitar el acceso en el frontend.
      const mappedCorte = {
        fecha_corte: data[0],
        total_efectivo: data[1],
        total_tarjeta: data[2],
        total_transferencia: data[3],
        total_general: data[4]
      };
      setCorteCaja(mappedCorte);
      showAlert(`Corte de caja para ${fechaCorte} obtenido exitosamente.`);
    } catch (err) {
      console.error("Error al obtener el corte de caja:", err);
      setError(err);
      showAlert(`Error al obtener corte de caja: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProductToSale = () => {
    const productId = parseInt(currentProductToAddId);
    const quantity = parseInt(currentProductToAddQuantity);

    if (isNaN(productId) || isNaN(quantity) || quantity <= 0) {
      showAlert('Por favor, ingrese un ID de producto y una cantidad válida.');
      return;
    }

    const productFound = productos.find(p => p.id === productId);

    if (!productFound) {
      showAlert(`Producto con ID ${productId} no encontrado.`);
      return;
    }

    if (productFound.stock_actual < quantity) {
      showAlert(`Stock insuficiente para ${productFound.nombre}. Disponible: ${productFound.stock_actual}`);
      return;
    }

    const existingDetailIndex = newSale.detalles.findIndex(d => d.producto_id === productId);

    if (existingDetailIndex > -1) {
      // Actualizar cantidad si el producto ya está en el carrito
      const updatedDetalles = [...newSale.detalles];
      const newQuantity = updatedDetalles[existingDetailIndex].cantidad + quantity;

      if (productFound.stock_actual < newQuantity) {
        showAlert(`No se pueden añadir más unidades de ${productFound.nombre}. Stock insuficiente.`);
        return;
      }
      updatedDetalles[existingDetailIndex].cantidad = newQuantity;
      updatedDetalles[existingDetailIndex].subtotal_linea = newQuantity * productFound.precio_venta;
      setNewSale({ ...newSale, detalles: updatedDetalles });
    } else {
      // Añadir nuevo producto al carrito
      setNewSale(prevSale => ({
        ...prevSale,
        detalles: [
          ...prevSale.detalles,
          {
            producto_id: productFound.id,
            nombre_producto: productFound.nombre,
            cantidad: quantity,
            precio_unitario: productFound.precio_venta,
            subtotal_linea: quantity * productFound.precio_venta
          }
        ]
      }));
    }

    setCurrentProductToAddId('');
    setCurrentProductToAddQuantity(1);
  };

  const handleRemoveProductFromSale = (productId) => {
    setNewSale(prevSale => ({
      ...prevSale,
      detalles: prevSale.detalles.filter(d => d.producto_id !== productId)
    }));
  };

  const handleRegisterSale = async () => {
    if (newSale.detalles.length === 0) {
      showAlert('El carrito de venta está vacío. Añada productos para registrar la venta.');
      return;
    }
    if (!newSale.usuario_id) {
        showAlert('Por favor, seleccione un usuario para la venta.');
        return;
    }

    setLoading(true);
    setError(null);

    const detallesParaAPI = newSale.detalles.map(d => ({
        producto_id: d.producto_id,
        cantidad: d.cantidad,
        precio_unitario: d.precio_unitario
    }));

    try {
      const response = await fetch(`${API_BASE_URL}/api/ventas`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          cliente_id: newSale.cliente_id === '' ? null : parseInt(newSale.cliente_id),
          usuario_id: parseInt(newSale.usuario_id),
          metodo_pago: newSale.metodo_pago,
          detalles: detallesParaAPI
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.details || `Error HTTP al registrar venta: ${response.status}`);
      }
      const data = await response.json();
      showAlert(`Venta registrada exitosamente. ID: ${data.ventaId}. El stock se ha actualizado.`);
      
      // Limpiar formulario y recargar datos para ver el stock actualizado
      setNewSale({ cliente_id: '', usuario_id: '3', metodo_pago: 'EFECTIVO', detalles: [] });
      // Usar setTimeout para dar tiempo a que la alerta se muestre antes de la recarga
      setTimeout(() => window.location.reload(), 1500); 
    } catch (err) {
      console.error("Error al registrar la venta:", err);
      setError(err);
      showAlert(`Error al registrar venta: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };


  if (loading) return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      backgroundColor: '#f3f4f6'
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
        <div style={{
          animation: 'spin 1s linear infinite', borderRadius: '50%', height: '64px', width: '64px',
          borderTop: '4px solid #3b82f6', borderBottom: '4px solid #3b82f6'
        }}></div>
        <p style={{ color: '#4b5563', fontSize: '20px', fontWeight: '600' }}>Cargando datos... (puede tardar la primera vez)</p>
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    </div>
  );
  
  if (error) return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      backgroundColor: '#fee2e2'
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
        <p style={{ color: '#b91c1c', fontSize: '20px', fontWeight: '600' }}>Error: {error.message}</p>
        <button
          onClick={() => window.location.reload()}
          style={{
            backgroundColor: '#ef4444', color: 'white', fontWeight: 'bold',
            padding: '8px 16px', borderRadius: '6px', border: 'none',
            cursor: 'pointer', transition: 'background-color 0.3s'
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#dc2626'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#ef4444'}
        >
          Reintentar
        </button>
      </div>
    </div>
  );

  const totalCarrito = newSale.detalles.reduce((sum, item) => sum + item.subtotal_linea, 0);

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f3f4f6', padding: '32px' }}>
      <AlertDialog message={alertMessage} onClose={closeAlert} />

      <header style={{
        background: 'linear-gradient(to right, #2563eb, #1d4ed8)',
        color: 'white', padding: '24px', borderRadius: '12px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
      }}>
        <h1 style={{ fontSize: '36px', fontWeight: '800', textAlign: 'center', letterSpacing: '0.05em' }}>Tienda "La Moderna"</h1>
        <p style={{ textAlign: 'center', marginTop: '8px', fontSize: '18px', fontWeight: '300' }}>Gestión de Inventario y Ventas Simplificada</p>
      </header>

      <main style={{
        display: 'grid', gridTemplateColumns: '1fr', gap: '32px', marginTop: '32px'
      }}>
        {/* Columna Izquierda: Registro de Venta */}
        <section style={{
          backgroundColor: 'white', padding: '24px', borderRadius: '12px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', border: '1px solid #e5e7eb'
        }}>
          <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#333', marginBottom: '24px', borderBottom: '1px solid #e5e7eb', paddingBottom: '12px' }}>Registrar Nueva Venta</h2>
          
          <div style={{ marginBottom: '16px' }}>
            <label htmlFor="clienteId" style={{ display: 'block', color: '#4b5563', fontSize: '14px', fontWeight: 'bold', marginBottom: '8px' }}>ID Cliente (opcional):</label>
            <input
              type="number"
              id="clienteId"
              style={{
                boxShadow: '0 1px 2px rgba(0,0,0,0.05)', border: '1px solid #d1d5db', borderRadius: '6px',
                width: '100%', padding: '8px 12px', color: '#333', lineHeight: '24px',
                outline: 'none', transition: 'box-shadow 0.2s, border-color 0.2s'
              }}
              onFocus={(e) => { e.target.style.boxShadow = '0 0 0 3px rgba(59,130,246,0.5)'; e.target.style.borderColor = '#3b82f6'; }}
              onBlur={(e) => { e.target.style.boxShadow = '0 1px 2px rgba(0,0,0,0.05)'; e.target.style.borderColor = '#d1d5db'; }}
              value={newSale.cliente_id}
              onChange={(e) => setNewSale({ ...newSale, cliente_id: e.target.value })}
              placeholder="Ej: 1"
            />
          </div>

          <div style={{ marginBottom: '16px' }}>
            <label htmlFor="usuarioId" style={{ display: 'block', color: '#4b5563', fontSize: '14px', fontWeight: 'bold', marginBottom: '8px' }}>ID Usuario (Vendedor):</label>
            <input
              type="number"
              id="usuarioId"
              style={{
                boxShadow: '0 1px 2px rgba(0,0,0,0.05)', border: '1px solid #d1d5db', borderRadius: '6px',
                width: '100%', padding: '8px 12px', color: '#333', lineHeight: '24px',
                outline: 'none', transition: 'box-shadow 0.2s, border-color 0.2s'
              }}
              onFocus={(e) => { e.target.style.boxShadow = '0 0 0 3px rgba(59,130,246,0.5)'; e.target.style.borderColor = '#3b82f6'; }}
              onBlur={(e) => { e.target.style.boxShadow = '0 1px 2px rgba(0,0,0,0.05)'; e.target.style.borderColor = '#d1d5db'; }}
              value={newSale.usuario_id}
              onChange={(e) => setNewSale({ ...newSale, usuario_id: e.target.value })}
              placeholder="Ej: 3"
            />
          </div>

          <div style={{ marginBottom: '24px' }}>
            <label htmlFor="metodoPago" style={{ display: 'block', color: '#4b5563', fontSize: '14px', fontWeight: 'bold', marginBottom: '8px' }}>Método de Pago:</label>
            <select
              id="metodoPago"
              style={{
                boxShadow: '0 1px 2px rgba(0,0,0,0.05)', border: '1px solid #d1d5db', borderRadius: '6px',
                width: '100%', padding: '8px 12px', color: '#333', lineHeight: '24px',
                outline: 'none', transition: 'box-shadow 0.2s, border-color 0.2s'
              }}
              onFocus={(e) => { e.target.style.boxShadow = '0 0 0 3px rgba(59,130,246,0.5)'; e.target.style.borderColor = '#3b82f6'; }}
              onBlur={(e) => { e.target.style.boxShadow = '0 1px 2px rgba(0,0,0,0.05)'; e.target.style.borderColor = '#d1d5db'; }}
              value={newSale.metodo_pago}
              onChange={(e) => setNewSale({ ...newSale, metodo_pago: e.target.value })}
            >
              <option value="EFECTIVO">Efectivo</option>
              <option value="TARJETA">Tarjeta</option>
              <option value="TRANSFERENCIA">Transferencia</option>
            </select>
          </div>

          <div style={{ marginBottom: '24px', borderTop: '1px solid #e5e7eb', paddingTop: '16px' }}>
            <h3 style={{ fontSize: '20px', fontWeight: '600', color: '#333', marginBottom: '12px' }}>Añadir Productos al Carrito</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '16px' }}>
              <input
                type="number"
                style={{
                  boxShadow: '0 1px 2px rgba(0,0,0,0.05)', border: '1px solid #d1d5db', borderRadius: '6px',
                  padding: '8px 12px', color: '#333', lineHeight: '24px', flexGrow: 1,
                  outline: 'none', transition: 'box-shadow 0.2s, border-color 0.2s'
                }}
                onFocus={(e) => { e.target.style.boxShadow = '0 0 0 3px rgba(59,130,246,0.5)'; e.target.style.borderColor = '#3b82f6'; }}
                onBlur={(e) => { e.target.style.boxShadow = '0 1px 2px rgba(0,0,0,0.05)'; e.target.style.borderColor = '#d1d5db'; }}
                placeholder="ID Producto"
                value={currentProductToAddId}
                onChange={(e) => setCurrentProductToAddId(e.target.value)}
              />
              <input
                type="number"
                style={{
                  boxShadow: '0 1px 2px rgba(0,0,0,0.05)', border: '1px solid #d1d5db', borderRadius: '6px',
                  padding: '8px 12px', color: '#333', lineHeight: '24px', width: '96px',
                  outline: 'none', transition: 'box-shadow 0.2s, border-color 0.2s'
                }}
                onFocus={(e) => { e.target.style.boxShadow = '0 0 0 3px rgba(59,130,246,0.5)'; e.target.style.borderColor = '#3b82f6'; }}
                onBlur={(e) => { e.target.style.boxShadow = '0 1px 2px rgba(0,0,0,0.05)'; e.target.style.borderColor = '#d1d5db'; }}
                placeholder="Cant."
                value={currentProductToAddQuantity}
                onChange={(e) => setCurrentProductToAddQuantity(e.target.value)}
                min="1"
              />
              <button
                onClick={handleAddProductToSale}
                style={{
                  backgroundColor: '#3b82f6', color: 'white', fontWeight: 'bold',
                  padding: '8px 16px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                  transition: 'background-color 0.3s', flexShrink: 0, border: 'none', cursor: 'pointer'
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#2563eb'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#3b82f6'}
              >
                Añadir
              </button>
            </div>

            <div style={{ maxHeight: '240px', overflowY: 'auto', backgroundColor: '#f9fafb', padding: '12px', borderRadius: '6px', border: '1px solid #e5e7eb' }}>
              {newSale.detalles.length === 0 ? (
                <p style={{ color: '#6b7280', textAlign: 'center' }}>No hay productos en el carrito.</p>
              ) : (
                <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {newSale.detalles.map((item, index) => (
                    <li key={item.producto_id} style={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      backgroundColor: 'white', padding: '8px', borderRadius: '6px',
                      boxShadow: '0 1px 2px rgba(0,0,0,0.05)', border: '1px solid #f3f4f6'
                    }}>
                      <div>
                        <p style={{ fontWeight: '600', color: '#333' }}>{item.nombre_producto} (x{item.cantidad})</p>
                        <p style={{ fontSize: '14px', color: '#6b7280' }}>${item.subtotal_linea.toFixed(2)}</p>
                      </div>
                      <button
                        onClick={() => handleRemoveProductFromSale(item.producto_id)}
                        style={{
                          color: '#ef4444', fontWeight: '600', padding: '4px', borderRadius: '9999px',
                          transition: 'color 0.2s', border: 'none', background: 'none', cursor: 'pointer'
                        }}
                        onMouseOver={(e) => e.currentTarget.style.color = '#dc2626'}
                        onMouseOut={(e) => e.currentTarget.style.color = '#ef4444'}
                      >
                        Remover
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <p style={{ textAlign: 'right', fontSize: '20px', fontWeight: 'bold', color: '#333', marginTop: '16px' }}>Total Carrito: <span style={{ color: '#10b981' }}>${totalCarrito.toFixed(2)}</span></p>
          </div>

          <button
            onClick={handleRegisterSale}
            style={{
              width: '100%', backgroundColor: '#10b981', color: 'white', fontWeight: 'bold',
              padding: '12px 24px', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
              transition: 'background-color 0.3s, transform 0.3s', border: 'none', cursor: 'pointer'
            }}
            onMouseOver={(e) => { e.currentTarget.style.backgroundColor = '#059669'; e.currentTarget.style.transform = 'scale(1.02)'; }}
            onMouseOut={(e) => { e.currentTarget.style.backgroundColor = '#10b981'; e.currentTarget.style.transform = 'scale(1)'; }}
          >
            Confirmar y Registrar Venta
          </button>
        </section>

        {/* Columna Central: Resumen y Cortes */}
        <section style={{
          backgroundColor: 'white', padding: '24px', borderRadius: '12px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #e5e7eb'
        }}>
          <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#333', marginBottom: '24px', borderBottom: '1px solid #e5e7eb', paddingBottom: '12px' }}>Resumen y Reportes</h2>

          <div style={{ marginBottom: '24px', padding: '16px', backgroundColor: '#eff6ff', border: '1px solid #dbeafe', borderRadius: '8px', boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.05)' }}>
            <h3 style={{ fontSize: '20px', fontWeight: '600', color: '#1e40af', marginBottom: '8px' }}>Corte de Caja Diario</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
              <input
                type="date"
                value={fechaCorte}
                onChange={(e) => setFechaCorte(e.target.value)}
                style={{
                  padding: '8px', border: '1px solid #d1d5db', borderRadius: '6px',
                  outline: 'none', flexGrow: 1, transition: 'box-shadow 0.2s, border-color 0.2s'
                }}
                onFocus={(e) => { e.target.style.boxShadow = '0 0 0 3px rgba(59,130,246,0.5)'; e.target.style.borderColor = '#3b82f6'; }}
                onBlur={(e) => { e.target.style.boxShadow = 'none'; e.target.style.borderColor = '#d1d5db'; }}
              />
              <button
                onClick={handleCorteCaja}
                style={{
                  backgroundColor: '#7c3aed', color: 'white', fontWeight: 'bold',
                  padding: '8px 20px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                  transition: 'background-color 0.3s', border: 'none', cursor: 'pointer'
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#6d28d9'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#7c3aed'}
              >
                Ver Corte
              </button>
            </div>
            {corteCaja ? (
              <div>
                <p style={{ color: '#4b5563' }}>Total Efectivo: <span style={{ fontWeight: 'bold' }}>${corteCaja.total_efectivo.toFixed(2)}</span></p>
                <p style={{ color: '#4b5563' }}>Total Tarjeta: <span style={{ fontWeight: 'bold' }}>${corteCaja.total_tarjeta.toFixed(2)}</span></p>
                <p style={{ color: '#4b5563' }}>Total Transferencia: <span style={{ fontWeight: 'bold' }}>${corteCaja.total_transferencia.toFixed(2)}</span></p>
                <p style={{ fontSize: '18px', fontWeight: 'bold', color: '#333', marginTop: '8px' }}>Total General del Día: <span style={{ color: '#10b981' }}>${corteCaja.total_general.toFixed(2)}</span></p>
              </div>
            ) : (
                <p style={{ color: '#6b7280', fontSize: '14px' }}>Seleccione una fecha y haga clic en "Ver Corte".</p>
            )}
          </div>
          
          <h3 style={{ fontSize: '20px', fontWeight: 'bold', color: '#333', marginBottom: '16px', borderBottom: '1px solid #e5e7eb', paddingBottom: '8px' }}>Todos los Productos ({productos.length})</h3>
          <div style={{ maxHeight: '384px', overflowY: 'auto', border: '1px solid #e5e7eb', borderRadius: '8px', padding: '12px' }}>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {productos.map((producto) => (
                <li key={producto.id} style={{
                  padding: '12px', backgroundColor: '#f9fafb', borderRadius: '8px',
                  boxShadow: '0 1px 2px rgba(0,0,0,0.05)', display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                  transition: 'background-color 0.15s', cursor: 'pointer'
                }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f3f4f6'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#f9fafb'}
                >
                  <p style={{ fontSize: '18px', fontWeight: '500', color: '#111827' }}>{producto.nombre} (ID: {producto.id})</p>
                  <p style={{ fontSize: '14px', color: '#6b7280' }}>Stock: {producto.stock_actual} | Precio: ${producto.precio_venta.toFixed(2)}</p>
                  {producto.fecha_caducidad && <p style={{ fontSize: '12px', color: '#9ca3af' }}>Caducidad: {producto.fecha_caducidad}</p>}
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Columna Derecha: Alertas de Inventario */}
        <section style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: '32px' }}>
          {/* Productos Bajo Stock */}
          <div style={{
            backgroundColor: '#fffbeb', padding: '24px', borderRadius: '12px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #fcd34d'
          }}>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#b45309', marginBottom: '16px', borderBottom: '1px solid #fcd34d', paddingBottom: '12px' }}>¡Alerta! Bajo Stock ({productosBajoStock.length})</h2>
            <div style={{ maxHeight: '240px', overflowY: 'auto' }}>
              {productosBajoStock.length === 0 ? (
                <p style={{ color: '#6b7280', textAlign: 'center', padding: '16px' }}>¡Todo en orden con el stock!</p>
              ) : (
                <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {productosBajoStock.map((producto) => (
                    <li key={producto.id} style={{
                      padding: '12px', backgroundColor: '#fef3c7', borderRadius: '8px',
                      boxShadow: '0 1px 2px rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      transition: 'background-color 0.15s', cursor: 'pointer'
                    }}
                    onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#fae4a7'}
                    onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#fef3c7'}
                    >
                      <div>
                        <p style={{ fontSize: '18px', fontWeight: '600', color: '#854d09' }}>{producto.nombre}</p>
                        <p style={{ fontSize: '14px', color: '#a16207' }}>Stock: {producto.stock_actual} | Precio: ${producto.precio_venta.toFixed(2)}</p>
                      </div>
                      <span style={{
                        backgroundColor: '#fbbf24', color: '#854d09', fontSize: '12px',
                        fontWeight: '600', padding: '4px 8px', borderRadius: '9999px'
                      }}>¡Urge Reabastecer!</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Productos Por Caducar */}
          <div style={{
            backgroundColor: '#fef2f2', padding: '24px', borderRadius: '12px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f87171'
          }}>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#dc2626', marginBottom: '16px', borderBottom: '1px solid #f87171', paddingBottom: '12px' }}>¡Urgente! Por Caducar ({productosPorCaducar.length})</h2>
            <div style={{ maxHeight: '240px', overflowY: 'auto' }}>
              {productosPorCaducar.length === 0 ? (
                <p style={{ color: '#6b7280', textAlign: 'center', padding: '16px' }}>No hay productos próximos a caducar.</p>
              ) : (
                <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {productosPorCaducar.map((producto) => (
                    <li key={producto.id} style={{
                      padding: '12px', backgroundColor: '#fee2e2', borderRadius: '8px',
                      boxShadow: '0 1px 2px rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      transition: 'background-color 0.15s', cursor: 'pointer'
                    }}
                    onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#fecaca'}
                    onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#fee2e2'}
                    >
                      <div>
                        <p style={{ fontSize: '18px', fontWeight: '600', color: '#991b1b' }}>{producto.nombre}</p>
                        <p style={{ fontSize: '14px', color: '#b91c1c' }}>Stock: {producto.stock_actual} | Caducidad: {producto.fecha_caducidad}</p>
                      </div>
                      <span style={{
                        backgroundColor: '#ef4444', color: '#991b1b', fontSize: '12px',
                        fontWeight: '600', padding: '4px 8px', borderRadius: '9999px'
                      }}>¡Promoción!</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer style={{ marginTop: '48px', textAlign: 'center', color: '#6b7280', fontSize: '14px' }}>
        <p>&copy; {new Date().getFullYear()} Tienda "La Moderna". Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}

export default App;
